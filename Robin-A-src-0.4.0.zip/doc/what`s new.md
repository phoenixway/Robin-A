# 0.4.0:
- Migrating to electron
- Build scripts for gulp, npm, nsis.
- Unit tests with Mocha.js.
- Mega refactoring.
- Mega bugfixing.
- Development workspaces: compile/transpile on-fly, etc. 
## Chatbot
- Chatbot wrapper with breaksilence and greeting.
- Get rid of websockets as way to communicate with chatbot.
- Chatbot simple ui.
## Experimenal
- RiveScript chatbot integrated.

# 0.3.1:
- Refactoring.
- Minor UI improvements.

